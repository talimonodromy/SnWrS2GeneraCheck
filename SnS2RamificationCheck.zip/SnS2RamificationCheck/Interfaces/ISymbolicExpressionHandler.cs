﻿using SnS2RamificationCheck.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace SnS2RamificationCheck.Interfaces
{
    public interface ISymbolicExpressionHandler
    {
        //lcm gcd is very basic - if integer return lcm, gcd integer, if parity information allows return 1 or product, else return some undefined. 
        public ISymbolicExpression lcm(ISymbolicExpression a, ISymbolicExpression b);

        public ISymbolicExpression gcd(ISymbolicExpression a, ISymbolicExpression b);

        public ISymbolicExpression Add(ISymbolicExpression exp1, ISymbolicExpression exp2);

        public Parity AssessParity(ISymbolicExpression exp1);

        public ISymbolicExpression Halve(ISymbolicExpression expr);
        public Dictionary<string, ParityAssumption> Assumptions { get; }

        public bool ExpressionsEqual(ISymbolicExpression expr1, ISymbolicExpression expr2);

    }
}
