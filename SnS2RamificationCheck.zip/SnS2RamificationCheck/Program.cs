﻿using SnS2RamificationCheck.Interfaces;
using SnS2RamificationCheck.Objects;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace SnS2RamificationCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Parsing Sn types from txt file");
            var snTypes = ParsingSetup.ParSnTypes();
            Console.WriteLine(String.Join(Environment.NewLine, snTypes.Select(t => t.ToString())));
        }

        public static void RamificationCalculations()
        {
            var assumptions = new Dictionary<String, ParityAssumption>() { { "n", new ParityAssumption(Parity.Odd) }, { "a", new ParityAssumption(Parity.Odd) } }; //just for funsies
            var symbolicExpressionHandler = new SymbolicExpressionHandler("n", "a", null, assumptions);
            var partitionHandler = new PartitionHandler(symbolicExpressionHandler);
            Console.WriteLine("Hello World!");

            //    Console.WriteLine("symmetric types");

            //calculate and print kernel types
            //         Console.WriteLine(String.Join(Environment.NewLine, StaticAndBenEll.ExceptionalSymmetricTypes.Select(t => t.ToString())));

            Console.WriteLine("wreath types to check");

            Console.WriteLine(String.Join(Environment.NewLine, StaticAndBenEll.WreathTypes.Select(t => t.ToString())));


            Console.WriteLine("Kernel types");
            var doer = new RamificationTypeCalculator(partitionHandler); //TODO add assumptions
            var kernel_types = doer.GetKernelTypes(StaticAndBenEll.WreathTypes);
            Console.WriteLine(String.Join(Environment.NewLine, kernel_types.Select(t => t.ToString())));

            Console.WriteLine("corresponding S_n x S_{n-1} types");
            var corresponding_symmetric_types = kernel_types.Select(t => doer.ProjectToRhsType(t));
            Console.WriteLine(String.Join(Environment.NewLine, corresponding_symmetric_types));
            var snTypesComparer = new SnRamificationTypeEqualityComparer();
            //lookup symmetric types
            var corresponding_exceptional_types = corresponding_symmetric_types.Where(t => StaticAndBenEll.ExceptionalSymmetricTypes.Contains(t, snTypesComparer));
            Console.WriteLine("Corresponding symmetric types");
            Console.WriteLine(String.Join(Environment.NewLine, corresponding_exceptional_types.Select(t => t.ToString())));
            //now do the same with types based in AnSn
            Console.WriteLine("SnAnTypes");
            var snanTypes = doer.GetSnAnTypes(kernel_types);
            Console.WriteLine(String.Join(Environment.NewLine, snanTypes.Select(t => t.ToString())));
            //now do the same for fiber types
            Console.WriteLine("fiber types");
            var fiberTypes = doer.GetFiberTypes(kernel_types);
            Console.WriteLine(String.Join(Environment.NewLine, fiberTypes.Select(t => t.ToString())));
            Console.WriteLine("AnAn Types");
            var anAnTypes = doer.GetAnAnTypesFromSnAnTypes(snanTypes);
            Console.WriteLine(String.Join(Environment.NewLine, anAnTypes.Select(t => t.ToString())));
        }
        public IEnumerable<SnRamificationType> ParseSnTypes()
        {
           return ParsingSetup.ParSnTypes();
        }
        //We want to return for every s
        public IEnumerable<Tuple<string, string, IEnumerable<string>>> CalculateSymmetricTypesInKernel(IEnumerable<SnWrS2RamificationType> input_types)
        {
            var res = new List<Tuple<string, string, List<String>>>();
            //TODO pass handler to constructor
            var doer = new RamificationTypeCalculator(null);
            var kernel_types = doer.GetKernelTypes(input_types);


            //calculate symmetric types with base snsn & match against list
            var corresponding_symmetric_types = kernel_types.Select(t => doer.ProjectToRhsType(t));
            //TODO check against list + at this point can still check genus!)
            var corresponding_anSn_types = new List<SnRamificationType>();

                
                
                
                var corrseponding_anan_types = new List<SnRamificationType>();

         
            
            return null;


        }

  


    }
}
