using Microsoft.VisualStudio.TestTools.UnitTesting;
using SnS2RamificationCheck;
using SnS2RamificationCheck.Interfaces;
using SnS2RamificationCheck.Objects;
using System;
using System.Collections.Generic;

namespace RamificationTests
{
    [TestClass]
    public class PartitionTests
    {

        [TestMethod]
        public void TestPartitionIsIdentity()
        {
            var handler = new SymbolicExpressionHandler("n", null, null,null);
            var partitionHandler = new PartitionHandler(handler);

            var transposition = new PartitionPart("2", "1");
            var transpositionPartition = new Partition(new List<PartitionPart> { transposition, new PartitionPart("1", "n-2") });

            Assert.IsFalse(transpositionPartition.IsIdentity());



            var part1 = new PartitionPart("1", "2");
            var partition2 = new Partition(new List<PartitionPart> { part1, new PartitionPart("1", "n-2") });
            Assert.IsTrue(partition2.IsIdentity());
        }

        [TestMethod]
        public void TestPartitionEquality()
        {
            var handler = new SymbolicExpressionHandler("n", null, null, null);
            var partitionHandler = new PartitionHandler(handler);

            var partition1 = new Partition(new List<PartitionPart> { new PartitionPart("1","2"), new PartitionPart("1", "n-2") });

            var partition2 = new Partition(new List<PartitionPart> { new PartitionPart("1", "n") });

            Assert.IsTrue(partitionHandler.PartitionEquals(partition1, partition2));
        }

        [TestMethod]
        public void TestSnRamificationTypeEqualityComparer()
        {
            var comparer = new SnS2RamificationCheck.Objects.SnRamificationTypeEqualityComparer();

            var strippedType = new SnRamificationType("I1.1", new List<SnBranchCycle>()
            {
                new SnBranchCycle(new SnS2RamificationCheck.Interfaces.Partition(new List<PartitionPart>() { new PartitionPart("n","1")})),
                new SnBranchCycle(new SnS2RamificationCheck.Interfaces.Partition(new List<PartitionPart>() { new PartitionPart("a","1"), new PartitionPart("n-a","1") })),
                new SnBranchCycle(new Partition(new List<PartitionPart>(){new PartitionPart("2","1"), new PartitionPart("1","n-2")}))
            });
            var typeWithExtraIdentities = new SnRamificationType("I1.1", new List<SnBranchCycle>()
            {
                new SnBranchCycle(new SnS2RamificationCheck.Interfaces.Partition(new List<PartitionPart>() { new PartitionPart("n","1")})),
                new SnBranchCycle(new SnS2RamificationCheck.Interfaces.Partition(new List<PartitionPart>() { new PartitionPart("a","1"), new PartitionPart("n-a","1") })),
                new SnBranchCycle(new Partition(new List<PartitionPart>(){new PartitionPart("2","1"), new PartitionPart("1","n-2")})),
                                new SnBranchCycle(new Partition(new List<PartitionPart>(){new PartitionPart("1","2"), new PartitionPart("1","n-2")}))
            });

            Assert.IsTrue(strippedType.Equals(typeWithExtraIdentities));

        }
    }


   
}
