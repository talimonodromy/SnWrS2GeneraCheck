﻿using SnS2RamificationCheck.Objects;
using System.Collections.Generic;
using System.Linq;

namespace SnS2RamificationCheck
{
    public class RamificationTypeCalculator
    {

        private PartitionHandler _partitionHandler;

        public PartitionHandler PartitionHandler { get { return _partitionHandler; } }
        public RamificationTypeCalculator(PartitionHandler partitionHandler)
        {
            _partitionHandler = partitionHandler;
        }

        public Parity GetRamificationTypeParity(SnRamificationType sntype)
        {
            var res = 0;
            foreach (var cycle in sntype.BranchCycles)
            {
                res = (res + (int)PartitionHandler.GetParity(cycle.Partition)) % 2; //todo verify this is desired logic
            }
            return (Parity)res;
        }

        public Parity GetSnBranchCycleParity(SnBranchCycle snbranch)
        {
            return PartitionHandler.GetParity(snbranch.Partition);
        }
        public SnRamificationType ProjectToRhsType(SnSquaredRamificationType input_snsquaredtype)
        {
            var cycles = new List<SnBranchCycle>();
            foreach (var input_branchcycle in input_snsquaredtype.BranchCycles)
            {
                cycles.Add(new SnBranchCycle(input_branchcycle.RightHandPartition));
            }
            return new SnRamificationType(input_snsquaredtype.Name, cycles);
        }

        public IEnumerable<SnSquaredRamificationType> GetKernelTypes(IEnumerable<SnWrS2RamificationType> input_list)
        {

            var kernel_types = input_list.Select(t => KernelTypeFromSnS2Type(t));
            return kernel_types;
        }

        public IEnumerable<SnSquaredRamificationType> GetSnAnTypes(IEnumerable<SnSquaredRamificationType> input_list)
        {
            var snan_types = input_list.Select(t => SnAnTypeFromSnSquaredType(t));
            return snan_types;
        }

        public IEnumerable<SnSquaredRamificationType> GetFiberTypes(IEnumerable<SnSquaredRamificationType> input_list)
        {
            var fiber_types = input_list.Select(t => FiberRamificationTypeFromSnSquaredType(t));
            return fiber_types;
        }
        public SnSquaredBranchCycle GetSecondPower(SnSquaredBranchCycle c)
        {
            return new SnSquaredBranchCycle(PartitionHandler.GetSecondPower(c.LeftHandPartition), PartitionHandler.GetSecondPower(c.RightHandPartition));
        }

        public SnSquaredRamificationType FiberRamificationTypeFromSnSquaredType(SnSquaredRamificationType snsnType)
        {
            var res_cycles = new List<SnSquaredBranchCycle>();
            foreach(var branch in snsnType.BranchCycles)
            {
                //compare rhs and lhs signs. If same, duplicate; else, raise both sides to 2nd power.
                var rhsSgn = PartitionHandler.GetParity(branch.RightHandPartition);
                var lhsSgn = PartitionHandler.GetParity(branch.LeftHandPartition);
                if (rhsSgn==lhsSgn)
                {
                    res_cycles.Add(branch);
                    res_cycles.Add(branch);
                }
                else
                {
                    res_cycles.Add(GetSecondPower(branch));
                }
            }
            return new SnSquaredRamificationType(snsnType.Name, res_cycles);
        }

        internal IEnumerable<SnSquaredRamificationType> GetAnAnTypesFromSnAnTypes(IEnumerable<SnSquaredRamificationType> snanTypes)
        {
            return snanTypes.Select(t => SnAnTypeFromSnSquaredType(t));
        }

        public SnSquaredRamificationType AnAnTypeFromSnSquaredTypeFromSnAnTypes(SnSquaredRamificationType snsnType)
        {
            // for each branch cycle, check sign of RHS, if it's odd -> halve, else -> duplicate
            var res_cycles = new List<SnSquaredBranchCycle>();
            foreach (var branch in snsnType.BranchCycles)
            {
                var rhsSgn = PartitionHandler.GetParity(branch.LeftHandPartition);
                switch (rhsSgn)
                {
                    case Parity.Odd:
                        res_cycles.Add(GetSecondPower(branch));
                        break;
                    case Parity.Even:
                        res_cycles.Add(branch);
                        res_cycles.Add(branch); //TODO is it OK to add two different instances here or will it cause a mess?
                        break;
                }
            }
            return new SnSquaredRamificationType(snsnType.Name, res_cycles);
        }
        public SnSquaredRamificationType SnAnTypeFromSnSquaredType(SnSquaredRamificationType snsnType)
        {
            // for each branch cycle, check sign of RHS, if it's odd -> halve, else -> duplicate
            var res_cycles = new List<SnSquaredBranchCycle>();
            foreach (var branch in snsnType.BranchCycles)
            {
                var rhsSgn = PartitionHandler.GetParity(branch.RightHandPartition);
                switch (rhsSgn)
                {
                    case Parity.Odd:
                        res_cycles.Add(GetSecondPower(branch));
                        break;
                    case Parity.Even:
                        res_cycles.Add(branch);
                        res_cycles.Add(branch); //TODO is it OK to add two different instances here or will it cause a mess?
                        break;
                }
            }
            return new SnSquaredRamificationType(snsnType.Name, res_cycles);
        }
       
        public SnSquaredRamificationType KernelTypeFromSnS2Type(SnWrS2RamificationType input_type)
        {
            var cycles = new List<SnSquaredBranchCycle>();
            foreach (var branch in input_type.BranchCycles)
            {
                if (branch.HasSwap())
                {
                    cycles.Add(new SnSquaredBranchCycle(branch.LeftHandPartition, branch.LeftHandPartition));
                }
                else
                {
                    cycles.Add(new SnSquaredBranchCycle(branch.LeftHandPartition, branch.RightHandPartition));
                    cycles.Add(new SnSquaredBranchCycle(branch.RightHandPartition, branch.LeftHandPartition));
                }
            }
            return new SnSquaredRamificationType(input_type.Name, cycles);
        }

    }
}
