﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnS2RamificationCheck.Interfaces
{
    public interface ISymbolicExpression
    {
        public string Expression { get; }
    }
}
