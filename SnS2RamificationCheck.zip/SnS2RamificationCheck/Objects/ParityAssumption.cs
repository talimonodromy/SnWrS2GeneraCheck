﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnS2RamificationCheck.Objects
{
    public class ParityAssumption
    {
       
        private int _modulo;
        private int _equivTo;

        public int Modulo { get { return _modulo; }  }
        public int EquivTo { get { return _equivTo; } }


        public ParityAssumption(Parity parity)
        {
            _modulo = 2;
            _equivTo = (int)parity;
        }

        public ParityAssumption(int modulo, int equivTo)
        {
            _modulo = modulo;
            _equivTo = equivTo;

        }

        public override string ToString()
        {
            return "=" + EquivTo + "mod" + Modulo;
        }

        public override int GetHashCode()
        {
            return (Modulo + EquivTo).GetHashCode();
        }
    }
}
