﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnS2RamificationCheck.Objects
{
    public class C2WrC2Element
    {
        public C2WrC2Element(bool rhs, bool lhs, bool swap)
        {   _rhs = rhs;
            _lhs = lhs;
            _swap = swap;
                }
        private bool _rhs;
        
        public bool RightHandSide { get { return _rhs; } }

        private bool _lhs;

        public bool LeftHandSide { get { return _lhs;  } }

        private bool _swap;

        public bool Swap { get { return _swap; } }
    }
}
